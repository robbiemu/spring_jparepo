package com.cooksys.spring_jparepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJparepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJparepoApplication.class, args);
	}
}
